<?php
$conn = mysqli_connect("localhost","root","","ecommerce") or die("Connection to database failed");
?>