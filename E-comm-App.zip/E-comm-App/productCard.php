<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// $data = json_decode(file_get_contents("php://input"), true);
$pro_id = $_POST['pro_id'];

include "config.php";

// $query = "SELECT p.*, pr.*, pc.color, pc.color_id, ps.size, ps.size_id, COUNT(pr.review_id), AVG(rating) FROM product p
//           LEFT JOIN pro_reviews pr ON p.pro_id = pr.pro_id
//           LEFT JOIN pro_colors pc ON p.pro_id = pc.pro_id
//           LEFT JOIN pro_sizes ps ON p.pro_id = ps.pro_id
//           WHERE p.pro_id = {$pro_id};";
$query = "SELECT * FROM product WHERE pro_id = {$pro_id};";

$result = $conn->query($query);

$products = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

echo json_encode($products);

mysqli_close($conn);
?>
