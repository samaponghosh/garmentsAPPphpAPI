<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// $data = json_decode(file_get_contents("php://input"), true);
$pro_id = $_POST['pro_id'];
$cus_id = $_POST['cus_id'];
$review = isset($_POST['review']) ? $_POST['review'] : null;
$rating = $_POST['rating'];
$review_image = isset($_POST['review_image']) ? $_POST['review_image'] : null;
// $current_date = date('Y-m-d');
$current_date = $_POST['current_date'];

include "config.php";

$q = "SELECT name FROM profile WHERE cus_id = {$cus_id};";
$CusName = mysqli_query($conn, $q);
if (mysqli_num_rows($CusName) > 0) {
    while ($row = mysqli_fetch_assoc($CusName)) {
        $name = $row['name'];
    }
} 

$q1 = "SELECT review_id FROM pro_reviews WHERE cus_id = {$cus_id} AND pro_id = {$pro_id};";
$check = mysqli_query($conn, $q1);
if (mysqli_num_rows($check) == 0)
{
    $que = "INSERT INTO pro_reviews(pro_id, name, cus_id, created_at, review, rating, review_image) VALUES('{$pro_id}','{$name}','{$cus_id}','{$current_date}','{$review}','{$rating}','{$review_image}')";
    $res = mysqli_query($conn, $que) or die("Query error");
    echo json_encode(array('message' => 'New review added successfully', 'status' => 200));
}
else
{
    echo json_encode(array('message' => 'Review already exixts, can not create new review', 'status' => false));
}

mysqli_close($conn);
?>
