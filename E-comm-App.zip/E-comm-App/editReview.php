<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// $data = json_decode(file_get_contents("php://input"), true);
$pro_id = $_POST['pro_id'];
$cus_id = $_POST['cus_id'];
$review = isset($_POST['review']) ? $_POST['review'] : null;
$rating = $_POST['rating'];
$review_image = isset($_POST['review_image']) ? $_POST['review_image'] : null;
// $current_date = date('Y-m-d');
$current_date = $_POST['current_date'];

include "config.php";

// $q = "SELECT name FROM profile WHERE cus_id = {$cus_id};";
// $CusName = mysqli_query($conn, $q);
// if (mysqli_num_rows($CusName) > 0) {
//     while ($row = mysqli_fetch_assoc($CusName)) {
//         $name = $row['name'];
//     }
// } 

$q1 = "SELECT review_id FROM pro_reviews WHERE cus_id = {$cus_id} AND pro_id = {$pro_id};";
$check = mysqli_query($conn, $q1);
if (mysqli_num_rows($check) > 0)
{
    while ($row = mysqli_fetch_assoc($check))
    {
        echo $review_id = $row['review_id'];
    }
    $que = "UPDATE pro_reviews SET created_at = '{$current_date}', review = '{$review}', rating = '{$rating}', review_image = '{$review_image}' WHERE review_id = {$review_id};";
    $res = mysqli_query($conn, $que) or die("Query error");
    echo json_encode(array('message' => 'Review edited successfully', 'status' => 200));
}
else
{
    echo json_encode(array('message' => 'Review does not exixts, can not edit review', 'status' => false));
}

mysqli_close($conn);
?>
